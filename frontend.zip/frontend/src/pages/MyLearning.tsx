import React from 'react'

const MyLearning = () => {
  return (
    <div>MyLearning</div>
  )
}

export default MyLearning