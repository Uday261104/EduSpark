import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import api from "@/lib/axios";
import type { Course } from "@/types/course";
import CourseCard from "@/components/CourseCard";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/auth-context";

/* ================= CATEGORIES ================= */
const categories: string[] = [
  "Web Development",
  "Data Science",
  "Cloud Computing",
  "DevOps",
  "Mobile Apps",
  "Databases",
  "AI & ML",
  "Cyber Security",
];

/* ================= HERO BANNERS ================= */
const banners = [
  {
    image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f",
    title: "Share the gift of learning",
    subtitle: "Save 20% on a year of unlimited access to top courses.",
    cta: "Explore courses",
  },
  {
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3",
    title: "Upskill Faster",
    subtitle: "Learn from industry experts worldwide.",
    cta: "Start learning",
  },
  {
    image: "https://images.unsplash.com/photo-1501504905252-473c47e087f8",
    title: "Career-Ready Skills",
    subtitle: "AI, Web, Cloud & Data career paths.",
    cta: "View paths",
  },
];

const Home = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [courses, setCourses] = useState<Course[]>([]);
  const [current, setCurrent] = useState(0);
  const [enrollments, setEnrollments] = useState<number[]>([]);

  /* ================= FETCH COURSES ================= */
  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const res = await api.get("/courses/");
        setCourses(res.data);
      } catch (err) {
        console.error("Failed to load courses", err);
      }
    };

    fetchCourses();
  }, []);

  /* ================= FETCH ENROLLMENTS ================= */
  const fetchEnrollments = async () => {
    if (!user) {
      setEnrollments([]);
      return;
    }

    try {
      const res = await api.get("/courses/my-enrollments/");
      const enrolledIds = res.data.map((course: any) =>
        Number(course.id)
      );
      setEnrollments(enrolledIds);
    } catch (err) {
      console.error("Failed to fetch enrollments", err);
    }
  };

  useEffect(() => {
    fetchEnrollments();
  }, [user]);

  /* ================= ENROLL ================= */
  const handleEnroll = async (courseId: number) => {
    if (!user) {
      navigate("/login");
      return;
    }

    try {
      await api.post(`/courses/${courseId}/enroll/`);
      await fetchEnrollments();
    } catch (err: any) {
      alert(err?.response?.data || "Enroll failed");
    }
  };

  /* ================= AUTO SLIDE ================= */
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % banners.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-gray-50 min-h-screen">

      {/* ================= WELCOME ================= */}
      {user && (
        <div className="max-w-7xl mx-auto px-4 pt-6">
          <h2 className="text-lg sm:text-xl font-semibold text-gray-800">
            Welcome,{" "}
            <span className="text-purple-600">
              {user.username}
            </span>{" "}
            👋
          </h2>
        </div>
      )}

      {/* ================= HERO ================= */}
      <section className="max-w-7xl mx-auto px-4 pt-6">
        <div className="relative h-[300px] rounded-2xl overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              className="absolute inset-0"
              initial={{ opacity: 0, x: 60 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -60 }}
              transition={{ duration: 0.7 }}
            >
              <img
                src={banners[current].image}
                className="h-full w-full object-cover"
                alt=""
              />
              <div className="absolute inset-0 bg-gradient-to-r from-purple-700/90 to-purple-500/60" />
            </motion.div>
          </AnimatePresence>

          <div className="relative z-10 h-full flex items-center px-10">
            <div className="max-w-xl text-white">
              <h1 className="text-3xl font-bold">
                {banners[current].title}
              </h1>
              <p className="mt-3 text-white/90">
                {banners[current].subtitle}
              </p>
              <button
                onClick={() => navigate("/courses")}
                className="mt-5 bg-white text-purple-700 px-6 py-2.5 rounded-lg font-semibold hover:bg-gray-100 transition"
              >
                {banners[current].cta}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ================= TOP COURSES ================= */}
      <section className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-2xl font-bold text-center mb-10">
          Top Courses
        </h2>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {courses.map((course) => (
            <motion.div
              key={course.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <CourseCard
                course={course}
                isEnrolled={
                  user
                    ? enrollments.includes(Number(course.id))
                    : false
                }
                onEnroll={handleEnroll}
              />
            </motion.div>
          ))}
        </div>
      </section>

      {/* ================= CTA ================= */}
      <section className="bg-white py-16">
        <div className="max-w-3xl mx-auto text-center px-6">
          <h2 className="text-2xl font-bold">
            Start Learning Today
          </h2>
          <p className="text-gray-600 mt-3">
            Join thousands of learners building real-world skills.
          </p>

          <button
            onClick={() => {
              if (!user) {
                navigate("/register");
              } else {
                navigate("/my-learning");
              }
            }}
            className="mt-6 bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-xl font-semibold transition"
          >
            {user ? "Go to My Learning" : "Create Free Account"}
          </button>
        </div>
      </section>

      {/* ================= FOOTER ================= */}
      <footer className="bg-gray-900 text-gray-400 text-center py-8 text-sm">
        <div className="font-semibold text-white mb-1">
          EduSpark LMS
        </div>
        <p>Learn. Build. Grow.</p>
        <p className="mt-2">
          © {new Date().getFullYear()} All rights reserved.
        </p>
      </footer>
    </div>
  );
};

export default Home;