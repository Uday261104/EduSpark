import { Routes, Route } from "react-router-dom"
import Navbar from "./components/Navbar"
import Login from "./pages/Login"
import { useAuth } from "./context/auth-context"
import Home from "./pages/Home"

export default function App() {

  const { user } = useAuth()

  console.log("User in Home Page:", user)

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navbar Always Visible */}
      <Navbar />

      {/* Page Content */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    </div>
  )
}