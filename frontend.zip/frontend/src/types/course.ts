export interface Course {
  id: number;
  title: string;
  description?: string;
  thumbnail?: string;
  total_hours?: number;
  category?: string;
  instructor?: string;
}