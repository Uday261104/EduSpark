import { createContext, useContext, useEffect, useState } from "react"

export interface User {
  id: number
  email: string
  role: string
  username?: string
}

interface AuthContextType {
  user: User | null
  loading: boolean
  setUser: (user: User | null) => void
  logout: () => void
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  setUser: () => {},
  logout: () => {},
})

export const useAuth = () => useContext(AuthContext)

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem("user")

      if (storedUser) {
        const parsedUser = JSON.parse(storedUser)

        if (parsedUser) {
          setUser(parsedUser)
          console.log("User fetched:", parsedUser)
        }
      }
    } catch (error) {
      console.error("Corrupted user data, clearing storage")
      localStorage.removeItem("user")
    }

    setLoading(false)
  }, [])

  const logout = () => {
    setUser(null)
    localStorage.removeItem("access")
    localStorage.removeItem("refresh")
    localStorage.removeItem("user")
  }

  return (
    <AuthContext.Provider value={{ user, loading, setUser, logout }}>
      {children}
    </AuthContext.Provider>
  )
}