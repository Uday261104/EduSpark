import { useAuth } from "@/context/auth-context"
import { Navigate } from "react-router-dom"

interface Props {
  children: React.ReactNode
  allowedRoles: string[]
}

export function ProtectedRoute({ children, allowedRoles }: Props) {
  const { user, loading } = useAuth()

  if (loading) return <div>Loading...</div>

  if (!user) return <Navigate to="/login" />

  if (!allowedRoles.includes(user.role))
    return <Navigate to="/unauthorized" />

  return <>{children}</>
}