import React from "react";
import type { Course } from "../types/course";
import { useNavigate } from "react-router-dom";

interface CourseCardProps {
  course: Course;
  isEnrolled?: boolean;
  onEnroll: (courseId: number) => void;
}

const CourseCard: React.FC<CourseCardProps> = ({
  course,
  isEnrolled = false,
  onEnroll,
}) => {
  const navigate = useNavigate();

  const imageUrl =
    course.thumbnail && course.thumbnail !== ""
      ? course.thumbnail.replace("localhost", "127.0.0.1")
      : null;

  const handleEnrollClick = (e: React.MouseEvent) => {
    e.stopPropagation(); // prevent card click
    if (!isEnrolled) {
      onEnroll(Number(course.id));
    }
  };

  const handleCardClick = () => {
    navigate(`/courses/${course.id}`);
  };

  return (
    <div
      onClick={handleCardClick}
      className="group cursor-pointer rounded-2xl bg-white border shadow-sm hover:shadow-2xl transition-all duration-300 overflow-hidden flex flex-col h-full"
    >
      {/* ================= Thumbnail ================= */}
      <div className="relative h-48 overflow-hidden">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={course.title}
            className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        ) : (
          <div className="flex h-full items-center justify-center bg-gradient-to-br from-purple-600 to-indigo-600">
            <span className="text-5xl font-bold text-white">
              {course.title?.charAt(0)}
            </span>
          </div>
        )}

        {/* FREE Badge */}
        <span className="absolute top-3 left-3 bg-green-500 px-3 py-1 text-xs font-bold text-white rounded-full shadow">
          FREE
        </span>

        {/* Duration */}
        <span className="absolute bottom-3 right-3 bg-white/90 backdrop-blur px-3 py-1 text-xs font-semibold rounded-full text-gray-800 shadow">
          {course.total_hours ?? 0} hrs
        </span>
      </div>

      {/* ================= Content ================= */}
      <div className="p-5 flex flex-col flex-1">
        <h3 className="text-lg font-bold text-gray-900 line-clamp-2 min-h-[3rem] group-hover:text-purple-600 transition">
          {course.title}
        </h3>

        <p className="mt-2 text-sm text-gray-600 line-clamp-3 mb-4">
          {course.description ?? ""}
        </p>

        {/* Enroll Button */}
        <button
          onClick={handleEnrollClick}
          disabled={isEnrolled}
          className={`mt-auto inline-flex items-center justify-center rounded-xl py-2.5 text-sm font-semibold transition-all duration-300 ${
            isEnrolled
              ? "bg-gray-200 text-gray-600 cursor-not-allowed"
              : "bg-purple-600 hover:bg-purple-700 text-white shadow-md"
          }`}
        >
          {isEnrolled ? "Enrolled ✓" : "Enroll Now"}
        </button>
      </div>
    </div>
  );
};

export default CourseCard;