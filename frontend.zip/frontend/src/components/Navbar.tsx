import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/auth-context";
import { useEffect, useState } from "react";

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [darkMode, setDarkMode] = useState(false);

  // Apply dark mode to html
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  const handleLogout = () => {
    logout();
    navigate("/", { replace: true });
  };

  // ✅ Always visible My Learning behavior
  const handleMyLearningClick = () => {
    if (!user) {
      navigate("/login"); // if not logged → go login
    } else {
      navigate("/my-learning");
    }
  };

  return (
    <nav className="bg-white dark:bg-gray-800 shadow-md px-8 py-4 transition-colors duration-300">
      <div className="flex justify-between items-center">

        {/* Logo */}
        <h1
          onClick={() => navigate("/")}
          className="text-2xl font-bold text-blue-600 dark:text-white cursor-pointer"
        >
          Eduspark
        </h1>

        {/* Center Links */}
        <div className="flex gap-6 text-gray-700 dark:text-gray-200 font-medium items-center">

          <Link to="/">Home</Link>

          {/* ✅ Always visible */}
          <button
            onClick={handleMyLearningClick}
            className="hover:text-blue-600"
          >
            My Learning
          </button>

          {/* Role-based extra links (only when logged in) */}
          {user && (
            <>
              {user.role === "Creator" && (
                <Link to="/my-courses">My Courses</Link>
              )}

              {user.role === "Admin" && (
                <Link to="/dashboard">Dashboard</Link>
              )}
            </>
          )}
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-4">

          {/* Dark Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="px-3 py-1 border rounded-md text-sm dark:text-white"
          >
            {darkMode ? "Light Mode" : "Dark Mode"}
          </button>

          {/* If NOT logged in */}
          {!user && (
            <>
              <button
                onClick={() => navigate("/login")}
                className="px-4 py-1 border rounded-md"
              >
                Login
              </button>

              <button
                onClick={() => navigate("/register")}
                className="px-4 py-1 bg-blue-600 text-white rounded-md"
              >
                Sign Up
              </button>
            </>
          )}

          {/* If logged in */}
          {user && (
            <>
              <span className="text-sm dark:text-white">
                {user.username}
              </span>

              <button
                onClick={handleLogout}
                className="px-4 py-1 bg-red-500 text-white rounded-md"
              >
                Logout
              </button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;